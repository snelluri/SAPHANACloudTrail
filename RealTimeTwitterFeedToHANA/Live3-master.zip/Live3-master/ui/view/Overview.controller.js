sap.ui.controller("view.Overview", {

	onNavButtonTap: function() {
		app.ref.AppView.splitApp.backMaster();
	}

});
