Live3
=====

SAP HANA Academy - Live3 project code samples for playlist https://www.youtube.com/playlist?list=PLkzo92owKnVwOu5o437oYi6O3ynesWZ9K
